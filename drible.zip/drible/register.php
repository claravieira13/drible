<?php
	require_once('config.php')
?>

<!DOCTYPE html>
<html>
<head>
	<title>Registo</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</head>
<body>
	<header>
		<img src="https://www.drible.pt/wp-content/uploads/2017/10/logodrible.png" data-rjs="https://www.drible.pt/wp-content/uploads/2017/10/logodrible_x2.png" alt="Drible // Marketing Digital &amp; Branding">

		<a class="float-right margin-right10" href="stripe/index.php">Subscrever Produtos</a>
	</header>

	<div>
		<?php
			if (isset($_POST['register'])) {
				$name     = $_POST['nome'];
				$email    = $_POST['email'];
				$password = $_POST['password'];

				mysql_connect("localhost", "root", "");
				mysql_select_db("drible");
				
				$existEmail = mysql_query("SELECT * FROM admin WHERE email = '$email'");
			    
			  
			    
			    if (mysql_num_rows($existEmail) == 1) {
			    	$_SESSION['admin_message'] = 'SUCESSO';
					
				}else{
					$sql = "INSERT INTO admin (nome, email, password) VALUES(?,?,?)";
					$insert = $db->prepare($sql);
					$result = $insert->execute([$name, $email, $password]);

					if ($result) {
						$_SESSION['success_message'] = 'SUCESSO';
						header('Location: /drible/login.php');
						
					}else{
						$_SESSION['error_message'] = 'ERROR';
						
					}
				}
			}
		?>
	</div>



	<div class="div-geral">
		<form action="register.php" method="post">
			<div class="container">
				<div class="row">
					<div class="offset-md-3 col-md-6">

						<h2 class="tx-center">Área de Registo</h2>
						<label for="nome">Nome</label>
						<input class="ip" type="text" name="nome" required>
						
						<label for="email">Email</label>
						<input class="ip" type="email" name="email" required>

			  			<label for="password">Password</label>
						<input class="ip" type="password" name="password" required>

						<p>Já tem conta? <a style="text-decoration:underline;" href="login.php">Inicie Sessão.</a></p>
						<input class="bt" type="submit" name="register" value="Registar">

						<?php if(isset($_SESSION['admin_message'])) : ?>
							<div class="alert alert-danger">
								<span class="margin-top20">Este email já se encontra registado, por favor inicie sessão.</span>
								<php unset($_SESSION['admin_message']); ?>
							</div>
						<?php endif?>

						<?php if(isset($_SESSION['error_message'])) : ?>
							<div class="alert alert-danger">
								<span class="margin-top20">Erro no registo.</span>
								<php unset($_SESSION['error_message']); ?>
							</div>
						<?php endif?>

						<?php if(isset($_SESSION['success_message'])) : ?>
							<div class="alert alert-success">
								<span class="margin-top20">Registo efetuado com sucesso.</span>
								<php unset($_SESSION['success_message']); ?>
							</div>
						<?php endif?>
						
					</div>
				</div>
				
			</div>
		</form>
	</div>
	
	
	<footer>
		<i class="fab fa-facebook-square"></i>
		<i class="fab fa-instagram-square"></i>
		<i class="fab fa-linkedin"></i>
	</footer>
	
</body>
</html>