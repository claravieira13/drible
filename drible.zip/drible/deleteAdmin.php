<?php
	
	include('config.php');

	$id = $_GET['id'];

	if( isset($_GET['id']) ){
		$servername = "localhost";

		$conn = new mysqli($servername, $db_user, $db_pass, $db_name);

		$sql = "DELETE FROM admin WHERE id = $id" ;
	    $result = $conn->query($sql);

		echo "<meta http-equiv='refresh' content='0;url=areaAdmin.php'>";
		 
	}


?>