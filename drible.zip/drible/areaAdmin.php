<?php
	require_once('config.php')
?>

<!DOCTYPE html>
<html>
<head>
	<title>Área Resevada - Administradores</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</head>
<body>
	<header><img src="https://www.drible.pt/wp-content/uploads/2017/10/logodrible.png" data-rjs="https://www.drible.pt/wp-content/uploads/2017/10/logodrible_x2.png" alt="Drible // Marketing Digital &amp; Branding"></header>

	<?php
		if (isset($_POST['adicionar'])) {
				$nome     = $_POST['nome'];
				$email    = $_POST['email'];
				$password = '123456';

				mysql_connect("localhost", "root", "");
				mysql_select_db("drible");
				
				$existEmail = mysql_query("SELECT * FROM admin WHERE email = '$email'");
			    
			  
			    
			    if (mysql_num_rows($existEmail) == 1) {
			    	$_SESSION['admin_message'] = 'SUCESSO';
					
				}else{
					$sql = "INSERT INTO admin (nome, email, password) VALUES(?,?,?)";
					$insert = $db->prepare($sql);
					$result = $insert->execute([$nome, $email, $password]);

					if ($result) {
						$_SESSION['success_message'] = 'SUCESSO';
						
						echo "<meta http-equiv='refresh' content='0;url=areaAdmin.php'>";
					}else{
						$_SESSION['error_message'] = 'ERROR';
						
					}
				}
			}
	?>

	<div class="div-geral">

		<div class="container">
			<div style=""> 
				<a href="areaProduto.php" class="menu">Produtos</a>	
				<a href="areaAdmin.php">Administradores</a>
			</div>

			<div class="row">
				<div class="col-md-12">
					<div style="padding:50px 0px;">
						<button class="bt" onclick="addAdmin();">Adicionar Administrador</button>
						<table>
						  	<tr>
						    	<th>Nome</th>
						    	<th>E-mail</th>
						    	<th>Opção</th>
						  	</tr>

							<?php

							$servername = "localhost";
							$username = "root";
							$password = "";
							$dbname = "drible";

							$conn = new mysqli($servername, $username, $password, $dbname);
					
							if ($conn->connect_error) {
							  die("Connection failed: " . $conn->connect_error);
							}

							$sql = "SELECT id, nome, email FROM admin";
							$result = $conn->query($sql);

							if ($result->num_rows > 0) {
								$cookie_name = 'email';

							  while($row = $result->fetch_assoc()) {
							  	$html = '';
							  	if (isset($_COOKIE[$cookie_name]) && ($_COOKIE[$cookie_name] != $row["email"])) {
							  		$html = '<a href="deleteAdmin.php?id='.$row["id"].'">
							    					<i class="fas fa-trash-alt"></i> Remover
							    				</a>';
							  	}

							    echo '	<tr>
							    			<td>' . $row["nome"]. '</td>
							    			<td>' . $row["email"]. '</td>
							    			<td>' .$html.'</td>
							    		</tr>';
							  }
							} else {
							  echo '<tr>
							  			<td>0 resultados</td>
							  			<td></td>
							  			<td></td>
							  		</tr>';
							}
							$conn->close();

								
							?>
						 
						</table>
					</div>
				</div>
			</div>

			<!--ADD ADMIN-->
			<div class="row">
				<div class="offset-md-3 col-md-6">
					<form action="areaAdmin.php" method="post">
						<div id="addAdmin" class="div-border" style="display:none;">
	    					<h4 class="margin-bottom20">Adicionar Administrador</h4>
							<label>Nome</label>
							<input class="ip" type="text" name="nome" required>
							<label>E-mail</label>
							<input class="ip" type="email" name="email" required>
							<input class="bt" type="submit" name="adicionar" value="Adicionar">

							<?php if(isset($_SESSION['error_message'])) : ?>
								<div class="alert alert-danger">
									<span class="margin-top20">Erro ao adicionar.</span>
									<php unset($_SESSION['error_message']); ?>
								</div>
							<?php endif?>

							<?php if(isset($_SESSION['success_message'])) : ?>
								<div class="alert alert-success">
									<span class="margin-top20">Adicionado com sucesso.</span>
									<php unset($_SESSION['success_message']); ?>
								</div>
							<?php endif?>

							<?php if(isset($_SESSION['admin_message'])) : ?>
								<div class="alert alert-danger">
									<span class="margin-top20">Este administrador já foi registado.</span>
									<php unset($_SESSION['admin_message']); ?>
								</div>
							<?php endif?>

						</div>
					</form>
					
				</div>
				
			</div>
		</div>
	
	</div>
	
	<footer>
		<i class="fab fa-facebook-square"></i>
		<i class="fab fa-instagram-square"></i>
		<i class="fab fa-linkedin"></i>
	</footer>
	
</body>
</html>

<script type="text/javascript">
	function addAdmin() {
  		var x = document.getElementById("addAdmin");
  		if (x.style.display === "none") {
    		x.style.display = "block";
  		}
	}
</script>