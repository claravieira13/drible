<?php
	
	include('config.php');

	$id = $_GET['id_novo'];

	if( isset($_GET['id_novo']) ){
		$servername = "localhost";

		$conn = new mysqli($servername, $db_user, $db_pass, $db_name);

		$sql = "DELETE FROM produtos WHERE id = $id" ;
	    $result = $conn->query($sql);

		echo "<meta http-equiv='refresh' content='0;url=areaProduto.php'>";
		 
	}


?>