<?php
	require_once('config.php')
?>

<!DOCTYPE html>
<html>
<head>
	<title>Acesso</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</head>
<body>
	<header>
		<img src="https://www.drible.pt/wp-content/uploads/2017/10/logodrible.png" data-rjs="https://www.drible.pt/wp-content/uploads/2017/10/logodrible_x2.png" alt="Drible // Marketing Digital &amp; Branding">

		<a class="float-right margin-right10" href="stripe/login.php">Subscrever Produtos</a>
	</header>

	<div>
		<?php

			mysql_connect("localhost", "root", "");
			mysql_select_db("drible");

			if(isset($_POST['email'])){
    
			    $email=$_POST['email'];
			    $password=$_POST['password'];
			    
			    $sql="select * from admin where email='".$email."'AND password='".$password."' limit 1";
			    
			    $result = mysql_query($sql);

			    $row = mysql_fetch_array($result);
			    if ($row['email'] == $email && $row['password'] == $password) {
			    	$_SESSION['success_message'] = 'SUCESSO';
			    	setcookie("email", $email, time() + (86400 * 30), "/");
			    	header('Location: /drible/areaProduto.php');
					
				}else{
					$_SESSION['error_message'] = 'ERROR';
					
				}    
			}
		?>
	</div>


	<div class="div-geral">
		<form action="login.php" method="post">
			<div class="container">
				<div class="row">
					<div class="offset-md-3 col-md-6">

						<h2 class="tx-center">Acesso</h2>

						<label for="email">Email</label>
						<input class="ip" type="email" name="email" required>

			  			<label for="password">Password</label>
						<input class="ip" type="password" name="password" required>

						<input class="bt" type="submit" name="login" value="Login">

						<?php if(isset($_SESSION['error_message'])) : ?>
							<div class="alert alert-danger margin-top20">
								<span class="">Erro ao iniciar sessão.</span>
								<php unset($_SESSION['error_message']); ?>
							</div>
						<?php endif?>

						<?php if(isset($_SESSION['success_message'])) : ?>
							<div class="alert alert-success margin-top20">
								<span class="margin-top20">Sessão iniciada com sucesso.</span>
								<php unset($_SESSION['success_message']); ?>
							</div>
						<?php endif?>
						
					</div>
				</div>
				
			</div>
		</form>
	</div>
	

	<footer>
		<i class="fab fa-facebook-square"></i>
		<i class="fab fa-instagram-square"></i>
		<i class="fab fa-linkedin"></i>
	</footer>
</body>
</html>