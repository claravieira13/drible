<?php
	require_once('config.php')
?>

<!DOCTYPE html>
<html>
<head>
	<title>Área Resevada - Produtos</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</head>
<body>
	<header><img src="https://www.drible.pt/wp-content/uploads/2017/10/logodrible.png" data-rjs="https://www.drible.pt/wp-content/uploads/2017/10/logodrible_x2.png" alt="Drible // Marketing Digital &amp; Branding"></header>

	<?php
		if (isset($_POST['guardar'])) {
				$nome         = $_POST['nome'];
				$descricao    = $_POST['descricao'];
				$valor        = $_POST['valor'];

				$sql = "INSERT INTO produtos (nome, descricao, valor) VALUES(?,?,?)";
				$insert = $db->prepare($sql);
				$result = $insert->execute([$nome, $descricao, $valor]);

				if ($result) {
					$_SESSION['success_message'] = 'SUCESSO';
					echo "<meta http-equiv='refresh' content='0;url=areaProduto.php'>";
					
				}else{
					$_SESSION['error_message'] = 'ERROR';
					
				}
				
			}
	?>

	<div class="div-geral">

		<div class="container">
			<div style=""> 
				<a href="areaProduto.php" class="menu">Produtos</a>	
				<a href="areaAdmin.php">Administradores</a>
			</div>

		
			<div class="row">
				<div class="col-md-12">
					<div style="padding:50px 0px;">
						<button class="bt" onclick="addProd();">Adicionar Produto</button>
						<table>
						  	<tr>
						    	<th>Nome</th>
						    	<th>Descrição</th>
						    	<th>Valor €</th>
						    	<th>Opção</th>
						  	</tr>

							<?php

								$servername = "localhost";
								$username = "root";
								$password = "";
								$dbname = "drible";

								$conn = new mysqli($servername, $username, $password, $dbname);
							
								if ($conn->connect_error) {
								  die("Connection failed: " . $conn->connect_error);
								}

								$sql = "SELECT id, nome, descricao, valor FROM produtos";
								$result = $conn->query($sql);

								if ($result->num_rows > 0) {
								  
								  	while($row = $result->fetch_assoc()) {
								    echo '	<tr>
								    			<td>' . $row["nome"]. '</td>
								    			<td>' . $row["descricao"]. '</td>
								    			<td>' . $row["valor"]. '</td>
								    			<td>
								    				<a class="margin-right10" href="edit.php?edit='.$row["id"].'">
								    					<i class="fas fa-pencil-alt"></i> Editar
								    				</a> 
								    				<a href="delete.php?id_novo='.$row["id"].'">
								    					<i class="fas fa-trash-alt"></i> Remover
								    				</a>
								    			</td>
								    		</tr>';
									}
								} else {
							  		echo '<tr>
							  				<td>0 resultados</td>
							  				<td></td>
							  				<td></td>
							  				<td></td>
							  			</tr>';
							}
							$conn->close();

								
							?>
						</table>
						
					</div>
				</div>
			</div>

			<!--ADD PRODUCT-->
			<div class="row">
				<div class="offset-md-3 col-md-6">
					<form action="areaProduto.php" method="post">
						<div id="addProd" class="div-border" style="display:none;">
	    					<h4 class="margin-bottom20">Adicionar Produto</h4>
							<label>Nome</label>
							<input class="ip" type="text" name="nome" required>
							<label>Descrição</label>
							<input class="ip" type="text" name="descricao" required>
							<label>Valor</label>
							<input class="ip" type="text" name="valor" required>
							<input class="bt" type="submit"  name="guardar" value="Guardar">

							<?php if(isset($_SESSION['error_message'])) : ?>
								<div class="alert alert-danger">
									<span class="margin-top20">Erro ao guardar.</span>
									<php unset($_SESSION['error_message']); ?>
								</div>
							<?php endif?>

							<?php if(isset($_SESSION['success_message'])) : ?>
								<div class="alert alert-success">
									<span class="margin-top20">Guardado com sucesso.</span>
									<php unset($_SESSION['success_message']); ?>
								</div>
							<?php endif?>

						</div>
					</form>
					
				</div>
				
			</div>
		</div>
	
	</div>
	
	<footer>
		<i class="fab fa-facebook-square"></i>
		<i class="fab fa-instagram-square"></i>
		<i class="fab fa-linkedin"></i>
	</footer>
	

</body>
</html>

<script type="text/javascript">
	function addProd() {
  		var x = document.getElementById("addProd");
  		if (x.style.display === "none") {
    		x.style.display = "block";
  		}
	}


</script>