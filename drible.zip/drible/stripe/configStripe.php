<?php 
// Subscription plans 
$plans = array( 
    '1' => array( 
        'name' => 'Por semana', 
        'price' => 25, 
        'interval' => 'semana' 
    ), 
    '2' => array( 
        'name' => 'Por mês', 
        'price' => 85, 
        'interval' => 'mês' 
    ), 
    '3' => array( 
        'name' => 'Por ano', 
        'price' => 950, 
        'interval' => 'ano' 
    ) 
); 
$currency = "EUR";  
 
// Stripe API configuration  
define('STRIPE_API_KEY', 'sk_test_51GsEhWG4cbhcQHuvbsNq6fICkLEXimKVjIhzhC1aGkStUjtWoVV44G5QPQ3xoE6tRBGjMySBDQndnb38ooMiEI3z00rI9fQosW'); 
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51GsEhWG4cbhcQHuvt9xXOmA425Q37nIq8dp8wpnaHrdPUvg851kpgbAECKT2CuxLbfDZkLZNkVH77xVCI3YGVxEW00i37OWkIV'); 
  
// Database configuration  
define('DB_HOST', 'localhost'); 
define('DB_USERNAME', 'root'); 
define('DB_PASSWORD', ''); 
define('DB_NAME', 'drible');