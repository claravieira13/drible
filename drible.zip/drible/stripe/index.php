<?php 
// Include configuration file  
require_once 'configStripe.php'; 
?>

<!DOCTYPE html>
<html>
<head>
	<title>Subscrever Produto</title>

	<script src="https://js.stripe.com/v2/"></script>
	<script src="https://js.stripe.com/v3/"></script>
	<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

	<link rel="stylesheet" type="text/css" href="/drible/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/drible/css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

	<script>
		// Set your publishable key
		Stripe.setPublishableKey('pk_test_51GsEhWG4cbhcQHuvt9xXOmA425Q37nIq8dp8wpnaHrdPUvg851kpgbAECKT2CuxLbfDZkLZNkVH77xVCI3YGVxEW00i37OWkIV');

		// Callback to handle the response from stripe
		function stripeResponseHandler(status, response) {
		    if (response.error) {
		        // Enable the submit button
		        $('#payBtn').removeAttr("disabled");
		        // Display the errors on the form
		        $(".payment-status").html('<p>'+response.error.message+'</p>');
		    } else {
		        var $form = $("#paymentFrm");
		        // Get token id
		        var token = response.id;
		        // Insert the token into the form
		        $form.append($('<input type="hidden" name="stripeToken" />').val(token));
		        // Submit form to the server
		        $form.get(0).submit();
		    }
		}



		$(document).ready(function() {
		    // On form submit
		    $("#paymentFrm").submit(function() {
		        // Disable the submit button to prevent repeated clicks
		        $('#payBtn').attr("disabled", "disabled");
				
		        // Create single-use token to charge the user
		        Stripe.card.createToken({
		            number: $('#card_number').val(),
		            exp_month: $('#card_exp_month').val(),
		            exp_year: $('#card_exp_year').val(),
		            cvc: $('#card_cvc').val()
		        }, stripeResponseHandler);
				
		        // Submit from callback
		        return false;
		    });
		});
	</script>
</head>
<body>

	<header>
		<img src="https://www.drible.pt/wp-content/uploads/2017/10/logodrible.png" data-rjs="https://www.drible.pt/wp-content/uploads/2017/10/logodrible_x2.png" alt="Drible // Marketing Digital &amp; Branding">

		<a class="float-right margin-right10" href="stripe/index.php">Subscrever Produtos</a>
	</header>

	<div class="container">
		<div class="row">
			<div class="offset-md-3 col-md-6" style="padding:100px 0px;">
			    <form action="payment.php" method="POST" id="paymentFrm">
			        <div style="margin-bottom:40px;">
			            <h3 class="margin-bottom20">Subscrever Produto</h3>
						
			            
		                <p class="margin-bottom20">Selecione o plano</p>
		                <select name="subscr_plan" id="subscr_plan">
		                    <?php foreach($plans as $id=>$plan){ ?>
		                        <option value="<?php echo $id; ?>"><?php echo $plan['name'].' '.$plan['price'].'€/'.$plan['interval'].''; ?></option>
		                    <?php } ?>
		                </select>
			           
			        </div>
			        <div style="padding:20px;box-shadow: 0 4px 4px 0 rgba(0, 0, 0, 0.25);background-color: #fbfbfb;">
			            <!-- Display errors returned by createToken -->
			            <div class="card-errors"></div>
						
			            <!-- Payment form -->
			            <div class="form-group">
			                <label>Nome</label>
			                <input class="ip" type="text" name="name" id="name" placeholder="Nome" required="" autofocus="">
			            </div>
			            <div class="form-group">
			                <label>E-mail</label>
			                <input class="ip" type="email" name="email" id="email" placeholder="E-mail" required="">
			            </div>
			            <div class="form-group">
			                <label>Número de Cartão</label>
			                <input class="ip" type="text" name="card_number" id="card_number" placeholder="4242 4242 4242 4242" maxlength="16" autocomplete="off" required="">
			            </div>
			            <div class="row">
			                <div class="col-md-6">
			                    <div class="form-group">
			                        <label>Data de Expiração</label>
			                        <div class="row">
			                        	<div class="col-md-6">
				                            <input class="ip" type="text" name="card_exp_month" id="card_exp_month" placeholder="MM" maxlength="2" required="">
				                        </div>
				                        <div class="col-md-6">
				                            <input class="ip" type="text" name="card_exp_year" id="card_exp_year" placeholder="YYYY" maxlength="4" required="">
				                        </div>
			                        </div>
			                        
			                    </div>
			                </div>
			                <div class="col-md-6">
			                    <div class="form-group">
			                        <label>CVC</label>
			                        <input class="ip" type="text" name="card_cvc" id="card_cvc" placeholder="CVC" maxlength="3" autocomplete="off" required="">
			                    </div>
			                </div>
			            </div>
			            <button type="submit" class="btn btn-success" id="payBtn">Efectuar Pagamento</button>
			        </div>
			    </form>
		    </div>
		</div>
		
	</div>

	<footer>
		<i class="fab fa-facebook-square"></i>
		<i class="fab fa-instagram-square"></i>
		<i class="fab fa-linkedin"></i>
	</footer>
</body>
</html>