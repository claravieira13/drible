<?php
	require_once('config.php')
?>

<!DOCTYPE html>
<html>
<head>
	<title>Área Resevada</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
</head>
<body>
	<header><img src="https://www.drible.pt/wp-content/uploads/2017/10/logodrible.png" data-rjs="https://www.drible.pt/wp-content/uploads/2017/10/logodrible_x2.png" alt="Drible // Marketing Digital &amp; Branding"></header>

	<div>
		<?php
			mysql_connect("localhost", "root", "");
			mysql_select_db("drible");
			


			if (isset($_POST['editar'])) {
				$id        = $_POST['id'];
				$nome      = $_POST['nome'];
				$descricao = $_POST['descricao'];
				$valor     = $_POST['valor'];

				$sql = "UPDATE produtos SET nome='$nome', descricao = '$descricao', valor = '$valor' WHERE id='$id'";
				$res = mysql_query($sql);

				$_id    = $id;
				$_nome  = $nome;
		    	$_desc  = $descricao;
		    	$_valor = $valor;	

		    	echo "<meta http-equiv='refresh' content='0;url=areaProduto.php'>";
				
			}else{
				$id = $_GET['edit'];

				$sql="select * from produtos where id='".$id."'";
				    
			    $result = mysql_query($sql);

			    $row = mysql_fetch_array($result);
			    if ($row['id']) {
			    	$_id    = $row['id'];
			    	$_nome  = $row['nome'];
			    	$_desc  = $row['descricao'];
			    	$_valor = $row['valor'];	
				}
			}
			
			
		?>
	</div>

	

	<div class="container">
		
			<!--ADD PRODUCT-->
		<div class="row">
			<div class="offset-md-3 col-md-6">
				<div class="div-geral">
					<form action="edit.php" method="post">
						<div class="div-border">
	    					<h4 class="margin-bottom20">Editar Produto</h4>
							<label>Nome</label>
							<input type="hidden" name="id" value="<?php echo $_id?>">

							<input class="ip" type="text" name="nome" value="<?php echo $_nome?>" required>
							<label>Descrição</label>
							<input class="ip" type="text" name="descricao" value="<?php echo $_desc?>" required>
							<label>Valor</label>
							<input class="ip" type="text" name="valor" value="<?php echo $_valor?>" required>
							<input class="bt" type="submit"  name="editar" value="Editar">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<footer>
		<i class="fab fa-facebook-square"></i>
		<i class="fab fa-instagram-square"></i>
		<i class="fab fa-linkedin"></i>
	</footer>
</body>
</html>
